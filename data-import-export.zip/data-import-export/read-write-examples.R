##############################################################
# CSC 522
# Examples of Reading Data into R
# Raju Vatsavai
##############################################################

rm(list=ls(all.names=T))


library(utils)          # for read/write csv files


# read csv files; first row is usually column (field) names
d = read.csv("abalone.csv")

# you can read as table
d = read.table("abalone.csv", header=T, sep=",")

# difference; read.csv() assumes separator is ","
# Both functions use same arguments
# header = T is default; if no header then don't forget to supply head=F

# data types
# data frames
# read.table() function returns an object of the type data.frame.
# data.frame data type captures the tabular representation of the data
# we can also view a data frame as a list of variables with individual
# observations as rows

# How to access data

rm(list=ls(all=T))

library(mclust)
library(lattice)
library(MASS)
library(car)
library(utils)          # for read/write csv files
library(flexclust)      # for kcca

# explore data first

dim(iris)
str(iris)
names(iris)

attributes(iris)

# explore subsets of data
iris[1:5, ]

# try head and tail (first and last x rows)
head(iris, 5)
tail(iris,5)

# explore individual columns
iris[1:5, "Sepal.Length"]
iris$Sepal.Length[1:5]

#what if you don't know the name
iris[1:5, 1]

# vectors -- just a sequence of numbers; the columns of a data frame are vectors as well
# c() function creates a vector
x = c(1,1,2,3,5)

# seq(i,j,step)
x = seq(1,5,1)

# we can use vectors to index data frames
iris[c(1,3,5),]

# attach() adds the column names to the R search path, so we can access them directly,
# without using the $ operator.

attach(iris)
Sepal.Length

# data frames vs. matrices
# An important difference between the two data types is that in a data frame,
# the columns can contain data of different data types.
# you can switch between these two data types
# as.matrix() and as.data.frame()

# dealing with missing data and other errors
data = read.csv("survery.csv")

# this dataset contains responses from 257 individuals to a basic health
# survey containing six questions (meaning 6 attributes)

# try to understand data types
# real-valued or quantitative variables: height and weight

# nominal or categorical or factors: sex and handedness
# sex and handedness variables take two values: male and female, and left- and
# right-handed, respectively
# These type of variables partition the data into disjoint categories

# R represents categorical variables using the factor data type.
# A vector can be converted into a factor by using the as.factor() function

# Ordinal: exercise and smoke; why?
# there is an implied relationship between the groups: exercising frequently
# is more than exercising sometimes which is more than doing no exercise.

data$smoke

# a factor can be converted into an ordinal variable using the ordered() function
# default is alphabetical; to enforce order we can use levels vector

data$smoke = ordered(data$smoke, levels=c(’Never’,’Occas’,’Regul’,’Heavy’))

# missing values; for categorical we can use unique()
unique(survey$sex)

# subsetting with which()
which(data$sex == ’F’)

# To replace the values of these entries, we use the output of the which
# function as an index

data$sex[which(data$sex == ’F’)] = ’Female’

# arbitrary subsets
which(data$sex == ’Male’ & data$weight > 150)

# boolean expression when indexed with a data frame or vector,
# it returns the rows corresponding to the true value

data$sex[data$sex == ’F’] = ’Female’

# treating missing values
data$height == NA

# not that much useful; is.na() is the appropriate function to use here
which(is.na(data$height))

# The standard R functions have support for NA’s
mean(data$height)
mean(data$height, na.rm = T)

# if na.fail(), then na.omit() and na.exclude()
data.clean = na.omit(data)

# imputing: simple data imputation is to replace with a value
data$height[is.na(data$height)] = 60

# exercise, replace with mean

# Removing the entries with missing values is also called list-wise deletion
# More on missing values/impuation later lectures

# after some manpulation, save as new file

d = iris[1:10,]
write.csv(d, file="new-iris.csv")


# if excel file
library(xlsx)

d = read.xlsx("somefile.xlx", sheetName="somesheet")

# you can connect to databases and read tables
library(RODBC)

db = db-odbcConnect()
sqlStmt = "SELECT * FROM my.table WHERE ..."
d = sqlQuery(db, sql)
odbcClose()
